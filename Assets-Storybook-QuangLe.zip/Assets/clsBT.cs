using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class clsBT : MonoBehaviour
{
public void SceneLoader(int sceneNumber)
{
    SceneManager.LoadScene(sceneNumber);
}
}
